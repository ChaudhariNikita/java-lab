package entity;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import service.Shop;

public class Transaction {
	private Customer customer;
	private Product product;
	private int quantity;

	public Transaction(Customer customer, Product product, int quantity) {
		this.customer = customer;
		this.product = product;
		this.quantity = quantity;
	}

	public Customer getCustomer() {
		return customer;
	}

	public Product getProduct() {
		return product;
	}

	public int getQuantity() {
		return quantity;
	}

	public double getTotalPrice() {
		return product.getPrice() * quantity;
	}

	public void saveDetailsToFile(String filename) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
			// System.out.println("\n========Shop Management System=======\n");
			writer.write(product.toString());
			writer.newLine();
			writer.write(customer.toString());
			writer.newLine();
			writer.write("-------------------------");
			writer.newLine();
			System.out.println("Product saved to file: " + filename);

		} catch (IOException e) {
			System.out.println("Error: " + e.getMessage());
		}

	}

}